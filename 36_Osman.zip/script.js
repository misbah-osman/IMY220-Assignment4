$(document).ready(() => {

   

    $("button").on('click', function(){

        
        if($(this).siblings('b').text() == "Name:"){

            var name = $(this).siblings('span').text();

            if($(this).text() == 'Edit'){

            $(this).text('Update');


            
                $('<input></input>', {
                    type: 'text',
                    class: 'name',
                    value: name
                    })
                    .insertAfter($(this).siblings('span'));
                    

            $(this).siblings('span').hide();
            $(this).siblings('b').hide();

            }
            else{
                $(this).text('Edit');
                $('.name').hide();
                name = $('.name').val();
                $(this).siblings('span').text(name);

                $(this).siblings('span').show();
                $(this).siblings('b').show();
            }





        }


        if($(this).siblings('b').text() == "Surname:"){

            var surname = $(this).siblings('span').text();

            if($(this).text() == 'Edit'){

            $(this).text('Update');

           

                $('<input></input>', {
                    type: 'text',
                    class: 'surname',
                    value: surname
                    })
                    .insertAfter($(this).siblings('span'));
                    

            $(this).siblings('span').hide();
            $(this).siblings('b').hide();

            }
            else{
                $(this).text('Edit');
                $('.surname').hide();
                surname = $('.surname').val();
                $(this).siblings('span').text(surname);

                $(this).siblings('span').show();
                $(this).siblings('b').show();
    
            }

        }


        if($(this).siblings('b').text() == "Email:"){

            var email = $(this).siblings('span').text();

            if($(this).text() == 'Edit'){

            $(this).text('Update');

         

            $('<input></input>', {
                    type: 'email',
                    id: 'email',
                    value: email,
                    class: "form-control col-8"
                    })
                    .insertAfter($(this).siblings('span'));
                
            


            $(this).siblings('span').hide();
            $(this).siblings('b').hide();

            }
            else{
                $(this).text('Edit');
                email = $('#email').val();
                $('#email').hide();
                $(this).siblings('span').text(email);
                $(this).siblings('b').show();
                $(this).siblings('span').show();
            }

        }


        if($(this).siblings('b').text() == "Birth date:"){

            var date = $(this).siblings('span').text();

            if($(this).text() == 'Edit'){

            $(this).text('Update');

      

            $('<input></input>', {
                type: 'date',
                class: 'date',
                value: date
                })
                .insertAfter($(this).siblings('span'));
                
            


            $(this).siblings('span').hide();
            $(this).siblings('b').hide();

        

            }
            else{
                $(this).text('Edit');
                $('.date').hide();
                date = $('.date').val();
                $(this).siblings('span').text(date);

                $(this).siblings('span').show();
                $(this).siblings('b').show();
    
              
            }

        }


        
        });



        
    });